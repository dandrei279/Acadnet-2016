/*
	Author : Alexandru Razvan CACIULESCU
*/

#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <termios.h>

/* magic clear screen macro */
#define clear() printf("\033[H\033[J")

/* predefined border chars, max length = 50 */
#define BORDER			"##################################################"
#define SPACES			"                                                  "

/* maze size */
#define SIZE			40

/* movement macros*/
#define MOVE_INC(x,size)		(++(x) < size ? x : size - 1)
#define MOVE_DEC(x)				(--(x) >= 0 ? x : 0)

#define SGN(x)					((x) > 0 ? 1 : 0)

#define TEST_MODE		0

void moveHunter(int &xH, int &yH, int xP, int yP, int size);

/* black magic for a better user experience,
change lines 117 and 118 to see the difference */
char getch()
{
	char buf = 0;
	struct termios old = {0};

	if (tcgetattr(0, &old) < 0)
		perror("tcsetattr()");

	old.c_lflag &= ~ICANON;
	old.c_lflag &= ~ECHO;
	old.c_cc[VMIN] = 1;
	old.c_cc[VTIME] = 0;

	if (tcsetattr(0, TCSANOW, &old) < 0)
		perror("tcsetattr ICANON");

	if (read(0, &buf, 1) < 0)
		perror ("read()");

	old.c_lflag |= ICANON;
	old.c_lflag |= ECHO;

	if (tcsetattr(0, TCSADRAIN, &old) < 0)
		perror ("tcsetattr ~ICANON");

	return (buf);
}


void drawMaze(int x, int y, int x2, int y2, int size)
{
	int i, j;

	printf("%.*s\n", size + 2, BORDER);

	for (i = 0; i < size / 2; i++) {
		if (i == x && i == x2) {
			if (y < y2) {
				printf("#%.*sH", y, SPACES);
				printf("%.*sP", y2 - y - 1, SPACES);
				printf("%.*s#\n", size - y2 - 1, SPACES);
			} else {
				printf("#%.*sP", y2, SPACES);
				printf("%.*sH", y - y2 - 1, SPACES);
				printf("%.*s#\n", size - y - 1, SPACES);
			}
		} else if (i == x) {
			printf("#%.*sH", y, SPACES);
			printf("%.*s#\n", size - y - 1, SPACES);
		} else if (i == x2) {
			printf("#%.*sP", y2, SPACES);
			printf("%.*s#\n", size - y2 - 1, SPACES);
		} else
			printf("#%.*s#\n", size, SPACES);
	}

	printf("%.*s\n", size + 2, BORDER);
}

/* You should use this */
int distance(int xH, int yH, int xP, int yP)
{
	return abs(xH - xP) + abs(yH - yP);
}

void movePrey(int xH, int yH, int &xP, int &yP)
{

	// TODO create the logic for the Prey to evade the Hunter

}


int main(void)
{
	int i, c;
	int x = 0, y = 0;
	int x2 = SIZE / 4, y2 = SIZE / 2;

	clear();

	drawMaze(x, y, x2, y2, SIZE);

	if(!TEST_MODE) {
		do {
			// c = getchar();
			c = getch();

			if (c == 'w')
				x = MOVE_DEC(x);
			else if (c == 'a')
				y = MOVE_DEC(y);
			else if (c == 's')
				x = MOVE_INC(x, SIZE / 2);
			else if (c == 'd')
				y = MOVE_INC(y, SIZE);

			clear();

			if (x == x2 && y == y2){
				printf("------------------YOU LOSE------------------\n");
				getch();
				return 1;
			}

			movePrey(x, y, x2, y2);
			drawMaze(x, y, x2, y2, SIZE);

		} while (c != 'q');
	} else {
		while(1) {
			usleep(50000);
			clear();
			if (x == x2 && y == y2){
				printf("------------------YOU LOSE------------------\n");
				getch();
				return 1;
			}

			moveHunter(x, y, x2, y2, SIZE);
			movePrey(x, y, x2, y2);
			drawMaze(x, y, x2, y2, SIZE);
		}
	}


	clear();

	return 0;
}
